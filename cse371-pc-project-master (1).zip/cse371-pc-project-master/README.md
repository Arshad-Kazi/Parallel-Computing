# cse371-pc-project
This is my team's project for CSE-371: Parallel Computing taught at IIT (BHU) Varanasi.

The project details are mentioned in the [Project Report](https://docs.google.com/document/d/1tj9oA501fQSgL0lFcoJhxstIohl-aX6x2hj0yifDFks/edit?usp=sharing).
